from django.contrib import admin
from patient_details.models import patient
# Register your models here.
admin.site.register(patient)