from django.shortcuts import render,redirect
from patient_details.models import patient
from django.contrib import messages

def home(request):
    obj=patient.objects.all()
    return render(request,'home.html',{'obj':obj})

def add_patient(request):
    if request.method=='POST':
        firstName=request.POST['firstname']
        lastName=request.POST['lastname']
        gender=request.POST['gender']
        age=request.POST['age']
        disease=request.POST['disease']
        doctorName=request.POST['doctorName']
        fee=request.POST['fee']
        meds=request.POST['meds']
        if not firstName.isdigit() and not lastName.isdigit():
            if disease.isalpha():
                if not doctorName.isdigit():
                    obj=patient(firstName=firstName,lastName=lastName,
                                gender=gender,age=age,disease=disease,doctorName=doctorName,doctorFee=fee,meds=meds)
                    obj.save()
                    return redirect('home')
                else:
                    messages.error(request,'Doctor name is invalid')
                    return redirect('add_patient')
            else:
                messages.error(request, 'Disease is invalid')
                return redirect('add_patient')
        else:
            messages.error(request, 'Patient name is invalid')
            return redirect('add_patient')
    else:
        return render(request,'add_patient.html')

def edit_details(request):
    if request.method=='POST':
        id=request.POST['id']
        firstName=request.POST['firstname']
        lastName=request.POST['lastname']
        gender=request.POST['gender']
        age=request.POST['age']
        doctorName=request.POST['doctor']
        disease=request.POST['disease']
        fee=request.POST['fee']
        meds=request.POST['meds']
        obj=patient.objects.get(id=id)
        obj.firstName=firstName
        obj.lastName=lastName
        obj.gender=gender
        obj.age=age
        obj.doctorName=doctorName
        obj.disease=disease
        obj.doctorFee=fee
        obj.meds=meds
        obj.save()
        messages.success(request,"Done..")
        return redirect('home')



def edit_patient(request):
    if request.method=='POST':
        id = request.POST['id']
        obj = patient.objects.get(id=id)
        return render(request,'edit_patient.html',{'data':obj})
    else:
        return render(request,'edit_patient.html')


def delete_patient(request):
    if request.method=='POST':
        id=request.POST['id']
        obj=patient.objects.get(id=id)
        obj.delete()
        messages.success(request,'Deleted Successfully..')
        return redirect('home')

def delete(request):
    obj=patient.objects.all()
    obj.delete()
    return redirect('home')


