import datetime
from django.db import models as mo

# Create your models here.

class patient(mo.Model):
    firstName=mo.TextField(max_length=10,default='')
    lastName=mo.TextField(max_length=10,default='')
    gender=mo.TextField(max_length=6,default='')
    age=mo.IntegerField(default=0)
    disease=mo.CharField(max_length=20,default='')
    doctorName=mo.TextField(max_length=15)
    doctorFee=mo.IntegerField(default=500)
    meds=mo.CharField(max_length=50,default='')


    def __str__(self):
        return self.firstName+self.lastName