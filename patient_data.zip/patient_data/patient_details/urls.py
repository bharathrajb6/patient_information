from django.urls import path
from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path('add_patient',views.add_patient,name='add_patient'),
    path('delete_patient',views.delete_patient,name='delete_patient'),
    path('edit_patient',views.edit_patient,name='edit_patient'),
    path('edit_details',views.edit_details,name='edit_details'),
    path('delete',views.delete,name='delete')
]